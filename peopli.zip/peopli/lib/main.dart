import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:peopli/config/app_route/binding/splash_binding.dart';
import 'package:peopli/config/app_route/route_names.dart';
import 'package:peopli/config/app_route/route_screen.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:peopli/features/home_screen/controller/home_controller.dart';
import 'package:peopli/features/splashscreen/splashscreen.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';

import 'config/app_theme/app_theme.dart';

void main() {
  runApp( MyApp());
}

class MyApp extends StatelessWidget {
   MyApp({Key? key}) : super(key: key);
    HomeController homeController=Get.put(HomeController());

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(375, 812),
      minTextAdapt: true,
      splitScreenMode: true,
        builder:(context, child) {
          return GetMaterialApp(





            debugShowCheckedModeBanner: false,
            theme: appThemeData,
            themeMode:homeController.theme,
            darkTheme: darkAppThemeData,
            initialRoute: NamedRoute.routeSplashScreen,
            initialBinding: SplashBinding(),
            getPages:Pages.pages,
            home:SplashScreen()
          );
        },
    );
  }
}

