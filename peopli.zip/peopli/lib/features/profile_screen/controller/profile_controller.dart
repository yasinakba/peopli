import 'package:get/get.dart';
import 'package:flutter/material.dart';

class ProfileController extends GetxController{

  late TabController tabController;
  @override
  void onInit() {

  }
}