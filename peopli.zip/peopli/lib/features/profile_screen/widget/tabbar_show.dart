import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:peopli/config/app_colors/app_colors_light.dart';
import 'package:peopli/config/app_icons/app_assets_png.dart';
import 'package:peopli/config/widgets/customButton.dart';
import 'package:peopli/features/profile_screen/widget/post_profile.dart';
import 'package:peopli/features/profile_screen/widget/post_profile2.dart';

class TabbarShow extends StatelessWidget {
  const TabbarShow({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(length: 2,
        initialIndex: 0,
        child: Scaffold(
          backgroundColor: AppLightColor.withColor,
          body: Column(
            children: [
              Container(

                height: 30.h,
                width: 375.w,
                child: TabBar(
                  unselectedLabelColor: AppLightColor.elipsFill,

                  labelColor: AppLightColor.textBoldColor,
                     indicatorColor: AppLightColor.withColor,
                  tabs: [
                    Container(

                      width: 112.w,
                      height: 16.h,
                      child: Icon(Icons.list)
                    ),

                    Container(
                      width: 112.w,
                      height: 16.h,
                      child: Icon(Icons.border_all)
                    ),



                  ],
                ),
              ),


              Expanded(
                child: Container(
                  color: AppLightColor.withColor,
                  child: TabBarView(

                    children: [
                      Center(
                        child: ListView.builder(

                          itemCount: 3,
                          itemBuilder: (BuildContext context,int index){
                          return PostProfile();
                        },),
                      ),
                      Center(
                        child: PostProfile2()
                      ),


                    ],
                  ),
                ),
              ),




            ],
          ),

        ));
  }
}
