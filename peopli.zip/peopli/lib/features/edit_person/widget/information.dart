import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:peopli/config/app_colors/app_colors_light.dart';
import 'package:peopli/config/app_theme/app_theme.dart';
import 'package:peopli/features/create_person/controller/create_perxon_controller.dart';

import '../controller/edit_person_controller.dart';
import 'flutter_map.dart';

class Information extends GetView<EditPersonController> {
  const Information({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<EditPersonController>(
      builder: (controller) => Container(
        width: 300.w,
        height: 220.h,
        decoration: BoxDecoration(
            color: AppLightColor.backgoundPost,
            borderRadius: BorderRadius.all(Radius.circular(25))),
        child: Column(

          children: [
            //location
            SizedBox(
                width: double.infinity,
                child: Padding(
                  padding: const EdgeInsets.only(top: 30, left: 10),
                  child: Text(
                    "Home Location :",
                    style: appThemeData.textTheme.bodyLarge,
                  ),
                )),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                    width: 220.w,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 15, top: 5),
                      child: Text(
                        "(2005-now) Avenue 13, Bond Pavilion, Mercury St., Paris, France",
                        maxLines: 2,
                        style: appThemeData.textTheme.bodySmall,
                      ),
                    )),
                Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: InkWell(
                    onTap: (){controller.editOpenDialogLocation(context);},
                    child: Text(
                      'Add',
                      style: appThemeData.textTheme.labelLarge!
                          .copyWith(color: AppLightColor.fillButton),
                    ),
                  ),
                )
              ],
            ),

            //Education
            Padding(
              padding: const EdgeInsets.only(top: 20),
              child: SizedBox(
                  width: double.infinity,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 10, left: 10),
                    child: InkWell(
                      onTap: (){controller.openDialog(context);},
                      child: Text(
                        "Education :",
                        style: appThemeData.textTheme.bodyLarge,
                      ),
                    ),
                  )),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                    width: 220.w,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 15, top: 5),
                      child: Text(
                        controller.education,
                        maxLines: 2,
                        style: appThemeData.textTheme.bodySmall,
                      ),
                    )),
                Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: InkWell(
                    onTap: (){controller.openDialog(context);},
                      child: Text(
                    'Add',
                    style: appThemeData.textTheme.labelLarge!
                        .copyWith(color: AppLightColor.fillButton),
                  )),
                )
              ],
            ),

            //Jobs
            Padding(
              padding: const EdgeInsets.only(top: 20),
              child: SizedBox(
                  width: double.infinity,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 10, left: 10),
                    child: Text(
                      "Job :",
                      style: appThemeData.textTheme.bodyLarge,
                    ),
                  )),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                    width: 220.w,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 15, top: 5),
                      child: Text(
                       controller.jobs,
                        maxLines: 2,
                        style: appThemeData.textTheme.bodySmall,
                      ),
                    )),
                Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: InkWell(
                    onTap: (){
                      controller.openDialogJobs(context);
                    },
                    child: Text(
                      'Add',
                      style: appThemeData.textTheme.labelLarge!
                          .copyWith(color: AppLightColor.fillButton),
                    ),
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }


}
