import 'package:flutter/material.dart';

import 'package:get/get.dart';

import 'package:peopli/config/widgets/custom_appbar.dart';
import 'package:peopli/features/first_screen/first_screen.dart';
import 'package:peopli/features/home_screen/controller/home_controller.dart';

import 'package:peopli/features/home_screen/widget/navigation_bar_widget.dart';
import 'package:peopli/features/person_screen/person_screen.dart';
import 'package:peopli/features/profile_screen/profile_screen.dart';
import 'package:peopli/features/search_screen/search_screen.dart';

import '../create_person/creat_person.dart';
import '../heart/heart.dart';
import '../search_screen/controller/search_controller.dart';

class HomeScreen extends GetView<HomeController> {
  HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: CustomeAppBar(),
        body: GetBuilder<HomeController>(
          builder: (c) => Stack(
            children: [
              PageView(
                  // index: controller.currentIndex,
                controller: controller.pageController,
                onPageChanged: controller.updateIndexNav,
                children: [
                  FirstScreen(),
                  SearchScreen(),
                  CreatePersonScreen(),
                  HeartScreen(),
                 ProfileScreen()
                ],
              ),
              Align(
                  alignment: Alignment.bottomCenter,
                  child: NavigationBarWidget()
              ),
            ],
          ),
        ));
  }
}
