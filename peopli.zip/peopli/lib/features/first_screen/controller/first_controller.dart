import 'package:get/get.dart';

class FirstController extends GetxController{

  @override
  void onInit() {

  }
}