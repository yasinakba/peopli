import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:peopli/features/edit_person/controller/edit_person_controller.dart';
import 'package:peopli/features/person_screen/controller/person_controller.dart';

class PersonEditBinding extends Bindings{
  @override
  void dependencies() {
   Get.put(EditPersonController());
  }

}