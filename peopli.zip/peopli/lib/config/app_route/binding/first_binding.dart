import 'package:get/get.dart';
import 'package:peopli/features/first_screen/controller/first_controller.dart';

class FirstBinding extends Bindings{
  @override
  void dependencies() {
   Get.put(FirstController());
  }
  
}