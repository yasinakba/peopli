import 'package:get/get.dart';
import 'package:peopli/features/add_memory/controller/add_memory_controller.dart';

class AddMemoryBinding extends Bindings{
  @override
  void dependencies() {
    Get.put(AddMemoryController());
  }

}