import 'package:get/get.dart';
import 'package:flutter/material.dart';


class NamedRoute{
  static String routeSplashScreen='/SplashScreen';
  static String routeHomeScreen='/HomeScreen';
  static String routeFirstScreen='/FirstScreen';
  static String routeSearchScreen='/SearchScreen';
  static String routeCreatePersonScreen='/CreatePersonScreen';
  static String routePersonScreen='/PersonScreen';
  static String routePersonEditScreen='/PersonEditScreen';
  static String routeAddMemoryScreen='/AddMemoryScreen';
  static String routePersonAddScreen='/PersonAddScreen';
  static String routeProfileScreen='/PersonAddScreen';
  static String routeLoginScreen='/LoginScreen';
  static String routeVerifyLoginScreen='/VerifyLoginScreen';
  static String routeAccountScreen='/AccountScreen';
  static String routeHeartScreen='/HeratScreen';
  static String routeEditProfiletScreen='/EditProfileScreen';
  static String routeForgetPassword='/ForgetPassword';

}