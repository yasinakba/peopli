class AppAssetsJpg {
  static const String imagePath="assets/images/jpg";

  static const String mohamad='$imagePath/10.jpg';

  static const String imagePerson='$imagePath/11.jpg';
  static const String userPost='$imagePath/3.jpg';
  static const String postImage='$imagePath/postImage.jpg';
  static const String listTileImage='$imagePath/image8.jpg';
  static const String gridImage='$imagePath/image1.jpg';
  static const String listTileCreateImage='$imagePath/image7.jpg';

}