class AppAssetsPng {
  static const String iconPath="assets/images/png";


  static const String iconNavbarOne='$iconPath/home .png';
  static const String iconNavbarTwo='$iconPath/search.png';
  static const String iconNavbarThree='$iconPath/plus 3.png';
  static const String iconNavbarFour='$iconPath/heart.png';
  static const String iconNavbarFive='$iconPath/picButton.png';
  static const String  iconComment='$iconPath/comment.png';
  static const String  iconLHeart='$iconPath/heart.png';
  static const String  iconShare='$iconPath/share.png';
  static const String  iconPlus='$iconPath/plus 3.png';
  static const String  logo='$iconPath/Logo.png';
  static const String  logo1='$iconPath/Logo.gif';

}