class AppFont {
  static const String vazir="vazir";



}