


class AppFonts{
  AppFonts._();
  static const String roboto="Roboto";
}