import 'package:flutter/material.dart';
import 'package:peopli/config/app_colors/app_colors_light.dart';
import 'package:peopli/config/app_fonts/app_font.dart';

class AppTextStylEn{

  // static  TextStyle displayLarge=TextStyle(fontSize: 20,color: AppLightColor.cancelButtonFill,fontFamily:AppFonts.roboto);
  // static  TextStyle displayMedium=TextStyle(fontSize: 18,color: AppLightColor.cancelButtonFill,fontWeight: FontWeight.bold);
  // static  TextStyle displaySmall=TextStyle(fontSize: 18,color: AppLightColor.cancelButtonFill);
  // static  TextStyle headlineLarge=TextStyle(fontSize: 14,color: AppLightColor.textBoldColor);
  // static  TextStyle headlineMedium=TextStyle(fontSize: 14,color: AppLightColor.cancelButtonFill,fontWeight: FontWeight.bold);
  // static  TextStyle headlineSmall=TextStyle(fontSize: 14,color: AppLightColor.cancelButtonFill,);
  // static  TextStyle titleLarge=TextStyle(fontSize: 14,color: AppLightColor.cancelButtonFill,);
  // static  TextStyle titleMedium=TextStyle(fontSize: 14,color: AppLightColor.strokeNeutral,fontWeight: FontWeight.bold);
  // static  TextStyle titleSmall=TextStyle(fontSize: 13,color: AppLightColor.cancelButtonFill,);
  // static  TextStyle labelLarge=TextStyle(fontSize: 12,color: AppLightColor.cancelButtonFill,);
  // static  TextStyle labelMedium=TextStyle(fontSize: 12,color: AppLightColor.cancelButtonFill,);
  // static  TextStyle labelSmall=TextStyle(fontSize: 12,color: AppLightColor.cancelButtonFill,);
  // static  TextStyle bodyLarge=TextStyle(fontSize: 10,color: AppLightColor.cancelButtonFill,);
  // static  TextStyle bodyMedium=TextStyle(fontSize: 10,color: AppLightColor.postNavbar,);
  // static  TextStyle bodySmall=TextStyle(fontSize: 10,color: AppLightColor.strokeRectangleType,);

}