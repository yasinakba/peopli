import 'dart:ui';

import 'package:flutter/material.dart';

class AppTextStyleFa{
  static TextStyle displayLarge=TextStyle(color: Colors.red);


}

var a=TextTheme(

);